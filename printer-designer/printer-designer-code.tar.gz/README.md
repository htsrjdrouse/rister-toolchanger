# 🖨️ Printer Designer

A web-based tool for designing printer bed layouts and generating G-code for liquid dispensing systems. Built for the **Rister Toolchanger** — a Voron Trident-based platform for nanoarray fabrication and perovskite solar cell deposition.

![Printer Designer](https://img.shields.io/badge/Status-Active-green) ![Docker](https://img.shields.io/badge/Docker-Ready-blue) ![License](https://img.shields.io/badge/License-MIT-yellow)

## ✨ Features

### 📦 Object Editor
- Visual canvas showing the printer bed layout
- Create, clone, and position objects (slides, plates, stations)
- Configure array patterns (rows, columns, spacing)
- Real-time coordinate display with mouse hover

### 💧 Tip Management
- Configure multiple dispenser tips (needle positions)
- Set up wash, waste, and drypad stations per tip
- Tip-specific coordinate offsets

### ⚙️ G-code Builder
- **Z Height Settings**: Configure dispense height and travel height
- Generate positioning G-code for objects and array positions
- Safe travel moves (lift → move → lower) to avoid dragging
- Save, load, and combine G-code sequences
- Copy to clipboard or download as `.gcode` files

### 🔬 Shape Designer (Line Generator)
- Generate parallel line patterns for nanoarray dispensing
- Configure line count, length, spacing, width, and height
- Hardware settings: needle gauge, syringe size
- Real-time 3D preview with Three.js
- Automatic extrusion calculation based on geometry
- **Custom G-code sections**: Before/After Printing, Before/After Line Set, Prime/Post-Dispense per line
- **Zigzag printing**: Alternate line direction for faster multi-line dispensing
- **Acceleration control**: Global and per-line acceleration settings
- **Per-line overrides**: Individual E multiplier and acceleration per line
- **3D bed preview**: Shows printer bed sized from Object Editor with 3D objects rendered at correct positions and heights
- **G-code-accurate visualization**: Dispense lines, zigzag direction arrows, and dashed travel moves match generated G-code exactly
- **Mouse coordinate tracking**: Hover over the 3D preview to see real-time X/Y position overlay
- Export ready-to-run G-code

### 🔌 Decoupled Pump Mode (Arduino Controller)
- **Independent XY and pump feedrates** — XY runs at F8000–F18000 while pump runs at F4000 minimum for sub-300µm lines
- **Arduino-based syringe pump** — Separate microcontroller (Arduino Micro + A4988) handles pump stepping
- **Trigger pin control** — Klipper output pin starts/stops the Arduino pump during dispense moves
- **Configurable trigger delay** — Millisecond delay between trigger and pump start for timing calibration
- **STORE command** — Pre-load dispense parameters (`STORE E{vol} F{rate}`) on the Arduino
- **TRIGGER_FIRE** — Single command to fire the trigger
- **Real-time line width estimation** — Shows estimated geometric width based on pump/XY ratio
- **Seamless toggle** — Switch between coupled (Klipper extruder) and decoupled (Arduino) modes

### ⏱️ Timing Calculator
- **Dispense time**: Calculated from Arduino pump parameters (E × 60 / F seconds, where F is mm/min)
- **Travel time**: Line length / (feedrate / 60) for XY moves
- **Hop time**: Inter-line travel time at travel feedrate
- **Per-line and total timing**: Auto-updates as parameters change
- **Valve synchronization**: Use calculated times to coordinate valve open/close with dispense moves

### 🔐 Publisher/Viewer Mode
- Optional password protection for editing
- Viewers can see designs and export G-code
- Publishers can create, edit, and delete designs
- **Auto-load last design**: Remembers your last loaded design and opens it automatically on next visit

## 🚀 Quick Start

### Docker (Recommended)

```bash
cd printer-designer
docker compose up -d
```

Access at: **http://localhost:3100**

To enable password protection:
```bash
PUBLISHER_PASSWORD=mysecret docker compose up -d
```

### Local Development

```bash
# Terminal 1: Backend
cd server
npm install
npm run dev

# Terminal 2: Frontend
cd client
npm install
npm start
```

- Backend: http://localhost:3100
- Frontend dev server: http://localhost:3000 (proxies to backend)

## 📁 Project Structure

```
printer-designer/
├── docker-compose.yml      # Docker orchestration
├── Dockerfile              # Production container build
├── server/
│   ├── index.js            # Express API server
│   ├── package.json
│   └── public/             # Built React app (production)
├── client/
│   ├── src/
│   │   ├── App.js                    # Main app with auth
│   │   ├── components/
│   │   │   ├── DesignList.js         # Design management
│   │   │   ├── ObjectEditor.js       # Visual bed editor
│   │   │   ├── TipManagement.js      # Dispenser tip config
│   │   │   ├── GcodeBuilder.js       # G-code sequence builder
│   │   │   ├── ShapeDesigner.js      # Line pattern generator + timing calculator
│   │   │   ├── NumInput.js           # Reusable numeric input component
│   │   │   └── LoginModal.js         # Auth UI
│   │   ├── context/
│   │   │   └── AuthContext.js        # Publisher authentication
│   │   └── styles/
│   │       └── main.css
│   └── package.json
└── data/
    └── designs.json        # Persistent design storage
```

## 🎮 Usage

### Creating a Design

1. Click **📁 Designs** → **➕ New Design**
2. Switch to **📦 Object Editor** to add substrates/plates
3. Configure **💧 Tip Management** for your dispenser positions
4. Use **⚙️ G-code Builder** to create movement sequences
5. Use **🔬 Shape Designer** to generate dispensing patterns

### Z Height Settings

The G-code Builder includes critical Z parameters:

| Setting | Default | Description |
|---------|---------|-------------|
| **Z Dispense** | 0.5 mm | Nozzle height while dispensing (close to substrate) |
| **Z Travel** | 10 mm | Height for safe travel moves between positions |

Generated G-code follows this pattern:
```gcode
G1 Z10 F1500      ; Lift to travel height
G1 X100 Y100 F3000 ; Move to position
G1 Z0.5 F500      ; Lower to dispense height
```

### Shape Designer Parameters

| Parameter | Description |
|-----------|-------------|
| **Number of Lines** | How many parallel lines to dispense |
| **Line Length** | Length of each line (mm) |
| **Line Spacing** | Distance between line centers (mm) |
| **Line Width** | Target width on substrate (mm) |
| **Line Height** | Target film thickness (mm) |
| **Start X/Y** | G-code coordinates for first line |
| **Needle Gauge** | 18G–34G (affects inner diameter) |
| **Syringe Size** | 1ml–20ml (affects plunger area) |
| **Dispense Speed** | Feedrate while dispensing (mm/min) |
| **Dispense Acceleration** | Acceleration during dispensing (mm/s²) |
| **Restore Acceleration** | Acceleration to restore after all lines (mm/s²) |
| **Z Dispense** | Height while dispensing |
| **Z Travel** | Height for moves between lines |
| **E Multiplier** | Global extrusion volume multiplier |
| **Per-Line Overrides** | Individual E multiplier and acceleration per line |
| **Zigzag Lines** | Alternate direction for faster printing (multi-line) |
| **Decoupled Pump** | Toggle Arduino pump mode (independent XY/pump feedrates) |
| **Pump Feedrate** | Arduino pump rate in mm/min (min F4000 for 30G needle) |
| **Trigger Delay** | Delay in ms between trigger pin HIGH and pump start |

### ⏱️ Timing Calculator

The timing calculator (in the Shape Designer panel) auto-computes timing for valve synchronization:

| Calculation | Formula | Notes |
|-------------|---------|-------|
| **Travel time** | `lineLength × 60 / feedrate` | XY move time per line (seconds) |
| **Dispense time** | `E × 60 / F` | Arduino pump time (F is mm/min, same as Klipper) |
| **Trigger delay** | `TD / 1000` | Converted from ms to seconds |
| **Hop time** | `lineSpacing × 60 / travelFeedrate` | Inter-line travel (seconds) |
| **Per-line total** | travel + dispense + trigger delay | Total time for one line |
| **Job total** | (per-line × numLines) + (hops × (numLines-1)) | Full print time estimate |

The Arduino pump uses the same feedrate convention as Klipper: F is in mm/min. With `rotation_distance: 24.534` and `microsteps: 16`, 1 E unit = 1 µL. So `STORE E100 F2000` dispenses 100µL at 2000mm/min = 3.0 seconds.

#### Per-Line Overrides

The **Per-Line Overrides** section allows fine-tuning of individual lines to compensate for stepper ramp-up effects or other line-specific requirements:

- **Collapsible UI**: Click to expand and see one row per line
- **E Multiplier**: Override global E multiplier for specific lines (e.g., 1.5 for Line 1, 1.3 for Line 2)
- **Acceleration**: Override global dispense acceleration per line (e.g., 300 mm/s² for Line 1)
- **Smart Defaults**: New lines initialize with global values; non-edited lines update when globals change
- **Use Case**: Compensate for under-dispense at line start by increasing E multiplier and/or reducing acceleration for first few lines

### Shape Designer G-code Sections

The Shape Designer supports custom G-code insertion at multiple points:

| Section | When | Visibility |
|---------|------|------------|
| **Before Printing** | Once at start of job | Always |
| **After Printing** | Once at end of job | Always |
| **Before Line Set** | Once before all lines | Multi-line only (numLines > 1) |
| **After Line Set** | Once after all lines (after Z lift) | Multi-line only (numLines > 1) |
| **Prime G-code** | Before each individual line | Always |
| **Post-Dispense G-code** | After each individual line | Always |

**G-code Structure:**
```gcode
; Setup (G21, G90, G92 E0)

; === Before Printing ===
[Your custom start G-code]

; Move to start position (XY first, then Z)

M204 S500  ; Set dispense acceleration

; === Before Line Set ===  (multi-line only)
[Runs once before all lines]

; Line 1 (E mult: 1.50)
M204 S300  ; Set line-specific acceleration (if different)
[Prime G-code - runs before each line]
G1 Y... E... F...  ; Dispense
[Post-Dispense G-code - runs after each line]

; Line 2 (E mult: 1.30) (zigzag: reverses direction if enabled)
M204 S400  ; Update acceleration (if different from previous)
[Prime G-code]
G1 Y... E... F...  ; Dispense (opposite direction)
[Post-Dispense G-code]

; Line 3 (E mult: 1.00)
M204 S500  ; Update acceleration (if different from previous)
[Prime G-code]
G1 Y... E... F...  ; Dispense
[Post-Dispense G-code]

; ... more lines ...

G1 Z... ; Lift to travel height
M204 S3000  ; Restore acceleration

; === After Line Set ===  (multi-line only)
[Runs once after all lines]

; === After Printing ===
[Your custom end G-code]
```

**Acceleration Control:**
- `M204 S{value}` sets acceleration at start of line set
- Per-line acceleration changes only emit `M204` when value differs from previous line
- Acceleration restored to travel value after all lines complete

## 🔌 API Reference

### Designs

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/designs` | - | List all designs |
| GET | `/api/designs/:id` | - | Get single design |
| POST | `/api/designs` | Publisher | Create new design |
| PUT | `/api/designs/:id` | Publisher | Update design |
| DELETE | `/api/designs/:id` | Publisher | Delete design |
| POST | `/api/designs/:id/clone` | Publisher | Clone design |
| GET | `/api/designs/:id/export` | - | Export as JSON |
| POST | `/api/designs/import` | Publisher | Import from JSON |

### Authentication

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/auth/status` | Check auth mode/status |
| POST | `/api/auth/login` | Login (get token) |
| POST | `/api/auth/logout` | Invalidate token |

## 🐳 Docker Commands

```bash
# Start (detached)
docker compose up -d

# Stop
docker compose down

# View logs
docker compose logs -f

# Rebuild after code changes
cd client && npm run build
cp -r build/* ../server/public/
docker compose restart

# Full rebuild (after Dockerfile changes)
docker compose build --no-cache
docker compose up -d
```

## 💾 Data Persistence

Designs are stored in `./data/designs.json`, mounted as a Docker volume.

**Backup:**
```bash
cp data/designs.json backups/designs_$(date +%Y%m%d).json
```

**Restore:**
```bash
cp backups/designs_20240206.json data/designs.json
docker compose restart
```

## 🔧 Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | 3100 | Server port |
| `PUBLISHER_PASSWORD` | *(none)* | Enable password protection |
| `NODE_ENV` | development | Set to `production` in Docker |

### docker-compose.yml

```yaml
services:
  printer-designer:
    build: .
    ports:
      - "3100:3100"
    environment:
      - PUBLISHER_PASSWORD=optional_password
    volumes:
      - ./data:/app/data
```

## 🎯 Use Cases

### Perovskite Solar Cell Fabrication
- Deposit parallel lines of perovskite precursor ink
- Configure for specific needle gauges (30G–34G typical)
- Calculate extrusion based on wet film requirements

### Nanoarray Printing
- Create patterns on glass slides or ITO-PET substrates
- Multiple substrate positions with array patterns
- Sequence generation for multi-layer deposition

### General Liquid Handling
- Any XYZ motion system with syringe pump
- Tip washing and waste disposal sequences
- Batch processing across multiple substrates

## 📝 License

MIT License — see [LICENSE](LICENSE) for details.

## 🤝 Contributing

Part of the [Rister Toolchanger](https://github.com/htsrjdrouse/rister-toolchanger) project.

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

---

*Built for low-cost, scalable perovskite solar fabrication* ☀️
